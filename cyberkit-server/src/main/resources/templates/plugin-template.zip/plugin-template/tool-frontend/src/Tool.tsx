import { proxyApiCall } from "./utils/proxyApiCall";

const Tool: React.FC = () => {
  return <></>;
};

export default Tool;
