1. Run 'npm install'.
2. Start coding in Tool.tsx -> You can see the UI display by running 'npm run dev' and access localhost:5173.
3. When you need to fetch api, use proxyApiCalls in src/utils/proxyApiCall.tsx. How to use it is shown below.
4. After you have done coding, run 'npm run build', there will be a /dist folder if you build successfully.
5. Navigate to the /dist folder, compress to .zip these files: index.html and /assets folder.
6. Upload the .zip file.

------------------------------------------------------------------------------------------------------------------------------
HOW TO USE proxyApiCall:

  const data = await proxyApiCall<ResponseType>("endpoint", "HTTP METHOD", RequestType);

Parameter:
  - ResponseType: data returned as an object with expected keys and values type
    for e.g.: { hash: string }

  - RequestBody: request body as an object with keys and values
    for e.g.: { text: "Hello world", salt: 10 }

  - endpoint: the action you want the plugin to execute, which will call that specific api
    for e.g.: /hash, /compare

  - HTTP METHOD: http method for calling the api
    for e.g.: GET, POST

Return type: object (JSON)

Example usage:
  const data = await proxyApiCall<{ hash: string }>("/hash", "POST", {
        text: "Password",
        salt: 10,
      });

  const data = await proxyApiCall<{ random: number }>("", "GET");

************************************************************

HOW TO USE requestClipboardCopy:

  requestClipboardCopy(content);

Parameter:
  - content: the content you want to copy to clipboard (of any type)

Return type: void

Example usage:
  () -> {requestClipboardCopy("Hello")}

