package com.cyberkit.tool;

import com.cyberkit.pluginservice.PluginService;

import java.util.HashMap;
import java.util.Map;

public class ToolServiceImpl implements PluginService {
    @Override
    public Map<String, Object> execute(String action, Map<String, Object> input) {
        Map<String, Object> result = new HashMap<>();

        return result;
    }
}
