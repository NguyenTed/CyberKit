1. Write code in ToolServiceImpl.java.
2. After finish coding, run 'mvn clean package', a /target folder will appear if build successfully.
3. Upload the .jar file in the /target folder
