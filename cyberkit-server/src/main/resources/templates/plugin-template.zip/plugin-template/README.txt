Upload .jar file to upload/tool-backend
Upload index.html and assets folder to upload/tool-frontend
Compress the 'upload' folder to .zip file
Upload the compressed file to the system